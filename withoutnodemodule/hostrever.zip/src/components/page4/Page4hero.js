import React from 'react';

const Page4hero = () => {
  return (
    <section className="bg-[#09113f] pt-32 pb-40">
      <div className="container mx-auto px-6 text-center">
        <h4 className=" md:text-5xl font-bold text-white leading-tight  mx-auto mb-6">
          Fast, Support Zero Hassle.
        </h4>
        <p className="text-xl md:text-1xl text-gray-100 mb-10">
        he standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 <br></br> and 1.10.33 from "de Finibus 
        </p>
       
      </div>
    </section>
  );
};

export default Page4hero;