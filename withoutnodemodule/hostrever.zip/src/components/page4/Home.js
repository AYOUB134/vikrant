import Navbar from '../Navbar';
import Page4hero from './Page4hero';
import Contect from './Contect'
import SupportSection from '../SupportSection'
import HostingFAQ from '../page2/HostingFAQ';
import Footer from '../Footer';
const Home = () => {
  return (
 <>
 <Navbar></Navbar>
<Page4hero></Page4hero>
<Contect></Contect>
<SupportSection></SupportSection>
<HostingFAQ></HostingFAQ>
<Footer></Footer>
 </>
  );
};

export default Home;
