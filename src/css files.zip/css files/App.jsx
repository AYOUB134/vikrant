import { useState } from 'react'
import Navbar from './components/Navbar'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import MainContent from './components/MainContent'
import ImageSlider from './components/ImageSlider'
import './App.css'

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="app">
      <Navbar />
      <div className="main-container">
        <Sidebar isOpen={isSidebarOpen} />
        <div className="content-area">
          <Header />
          <ImageSlider />
          <MainContent />
        </div>
      </div>
    </div>
  )
}

export default App

