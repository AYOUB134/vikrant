import Navbar from "./components/Navbar"
import Sidebar from "./components/Sidebar"
import MainContent from "./components/MainContent"
import RightSidebar from "./components/RightSidebar"

function App() {
  return (
    <div className="flex flex-col h-screen">
      <Navbar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <MainContent />
        <RightSidebar />
      </div>
    </div>
  )
}

export default App

