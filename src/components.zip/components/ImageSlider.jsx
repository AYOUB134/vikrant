import { useState, useEffect } from 'react'
import './ImageSlider.css'

const images = [
  "/placeholder.svg?text=Tennis+Tournament",
  "/placeholder.svg?text=Football+Match",
  "/placeholder.svg?text=Cricket+Series",
];

const ImageSlider = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) =>

