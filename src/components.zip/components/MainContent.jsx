"use client"

import { useState } from "react"
import "./MainContent.css"

const matchData = [
  {
    id: 1,
    tournament: "ICC Champions Trophy",
    team1: "Zimbabwe",
    team2: "Ireland",
    odds: { team1: 1.02, team2: 1.03 },
    scores: { team1: 38, team2: 40 },
  },
  {
    id: 2,
    tournament: "Ranji Trophy Elite 2024-25",
    team1: "Gujarat",
    team2: "Kerala",
    odds: { team1: 1.5, team2: 2.1 },
  },
  {
    id: 3,
    tournament: "Ranji Trophy Elite 2024-25",
    team1: "Vidarbha",
    team2: "Mumbai",
    odds: { team1: 1.8, team2: 1.9 },
  },
]

const MainContent = () => {
  const [selectedTab, setSelectedTab] = useState("Cricket")

  return (
    <div className="main-content">
      <div className="tabs">
        <button
          className={`tab ${selectedTab === "Cricket" ? "active" : ""}`}
          onClick={() => setSelectedTab("Cricket")}
        >
          Cricket
        </button>
        <button
          className={`tab ${selectedTab === "Football" ? "active" : ""}`}
          onClick={() => setSelectedTab("Football")}
        >
          Football
        </button>
        <button className={`tab ${selectedTab === "Tennis" ? "active" : ""}`} onClick={() => setSelectedTab("Tennis")}>
          Tennis
        </button>
      </div>

      <div className="matches">
        {matchData.map((match) => (
          <div key={match.id} className="match-card">
            <div className="match-header">
              <span>{match.tournament}</span>
              <span className="live-tag">LIVE</span>
            </div>
            <div className="match-content">
              <div className="teams">
                <span>{match.team1}</span>
                <span>vs</span>
                <span>{match.team2}</span>
              </div>
              <div className="odds">
                <button className="odd-btn">{match.odds.team1}</button>
                <button className="odd-btn">{match.odds.team2}</button>
              </div>
              {match.scores && (
                <div className="scores">
                  <span>{match.scores.team1}</span>
                  <span>{match.scores.team2}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default MainContent

