export default function Header() {
  return (
    <header className="header">
      <h1>Betting App</h1>
    </header>
  )
}

