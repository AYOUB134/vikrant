const navItems = ["Lottery", "SportBook1", "Exchange", "Live Casino", "Slot", "Fantasy Games"]

function Navbar() {
  return (
    <nav className="bg-red-800 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <img src="/logo.png" alt="Vikrant Exchange" className="h-8 mr-4" />
          <h1 className="text-xl font-bold">VIKRANT EXCHANGE</h1>
        </div>
        <ul className="hidden md:flex space-x-4">
          {navItems.map((item, index) => (
            <li key={index}>
              <a href="#" className="hover:text-gray-300">
                {item}
              </a>
            </li>
          ))}
        </ul>
        <div className="flex items-center space-x-4">
          <span>pts: 1500</span>
          <span>exp: 0</span>
          <button className="bg-white text-red-800 px-3 py-1 rounded">Demo</button>
        </div>
      </div>
    </nav>
  )
}

export default Navbar

