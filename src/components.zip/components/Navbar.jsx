import { User, Bell } from 'lucide-react'
import './Navbar.css'

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="nav-left">
        <img src="/placeholder.svg" alt="Logo" className="logo" />
        <div className="nav-links">
          <a href="#" className="active">Lottery</a>
          <a href="#">SportBook1</a>
          <a href="#">Exchange</a>
          <a href="#">Live Casino</a>
          <a href="#">Slot</a>
          <a href="#">Fantasy Games</a>
        </div>
      </div>
      <div className="nav-right">
        <div className="points">
          <span>pts: 1500</span>
          <span>exp: 0</span>
        </div>
        <Bell className="icon" />
        <User className="icon" />
        <button className="demo-btn">Demo</button>
      </div>
    </nav>
  )
}

export default Navbar

