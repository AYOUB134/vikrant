"use client"

import { useEffect, useRef } from "react"

const banners = [
  {
    id: 1,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-02-18%20at%2019.20.28_685d66e8.jpg-dipMUWPuimPSrsuP3pw7XaD7rXZR9S.jpeg",
    title: "Aero",
  },
  {
    id: 2,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-02-18%20at%2019.20.28_685d66e8.jpg-dipMUWPuimPSrsuP3pw7XaD7rXZR9S.jpeg",
    title: "Unique Roulette",
  },
  {
    id: 3,
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-02-18%20at%2019.20.28_685d66e8.jpg-dipMUWPuimPSrsuP3pw7XaD7rXZR9S.jpeg",
    title: "Jack Top",
  },
]

function RightSidebar() {
  const containerRef = useRef(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    let position = 0
    const scrollHeight = container.scrollHeight
    const height = container.clientHeight

    const scroll = () => {
      position = (position + 1) % scrollHeight
      container.scrollTop = position
      if (position >= scrollHeight - height) {
        position = 0
      }
    }

    const interval = setInterval(scroll, 50)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="w-64 bg-gray-100 overflow-hidden">
      <div ref={containerRef} className="h-full overflow-hidden">
        <div className="space-y-4 p-4">
          {banners.map((banner) => (
            <div key={banner.id} className="relative aspect-w-4 aspect-h-3 rounded-lg overflow-hidden shadow-md">
              <img src={banner.image || "/placeholder.svg"} alt={banner.title} className="object-cover w-full h-full" />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default RightSidebar

