"use client"

import { useState } from "react"

const sportsData = [
  {
    category: "Racing Sport",
    sports: ["Horse Racing", "Greyhound Racing"],
  },
  {
    category: "All Sport",
    sports: [
      "Politics(1)",
      "Cricket(24)",
      "Football(142)",
      "Tennis(102)",
      "Table Tennis(84)",
      "Badminton",
      "Esoccer(10)",
      "Basketball(66)",
      "Volleyball(58)",
      "Snooker",
    ],
  },
]

function Sidebar() {
  const [expandedCategory, setExpandedCategory] = useState("All Sport")

  return (
    <div className="w-64 bg-gray-100 overflow-y-auto">
      <div className="p-4">
        <input type="text" placeholder="Search" className="w-full p-2 border rounded" />
      </div>
      {sportsData.map((category) => (
        <div key={category.category}>
          <button
            className="w-full text-left p-4 font-bold bg-gray-200 hover:bg-gray-300"
            onClick={() => setExpandedCategory(category.category)}
          >
            {category.category}
          </button>
          {expandedCategory === category.category && (
            <ul className="py-2">
              {category.sports.map((sport, index) => (
                <li key={index} className="px-6 py-2 hover:bg-gray-200 cursor-pointer">
                  {sport}
                </li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  )
}

export default Sidebar

