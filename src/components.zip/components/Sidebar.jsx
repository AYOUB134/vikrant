import { useState } from 'react'
import './Sidebar.css'

const sportsData = [
  { id: 1, name: 'Horse Racing', count: 0 },
  { id: 2, name: 'Greyhound Racing', count: 0 },
  { id: 3, name: 'Politics', count: 1 },
  { id: 4, name: 'Cricket', count: 24 },
  { id: 5, name: 'Football', count: 142 },
  { id: 6, name: 'Tennis', count: 102 },
  { id: 7, name: 'Table Tennis', count: 84 },
  { id: 8, name: 'Badminton', count: 0 },
  { id: 9, name: 'Esoccer', count: 10 },
  { id: 10, name: 'Basketball', count: 66 },
  { id: 11, name: 'Volleyball', count: 58 },
  { id: 12, name: 'Snooker', count: 0 },
]

const Sidebar = ({ isOpen }) => {
  const [selectedSport, setSelectedSport] = useState(null);

  return (
    <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-section">
        <h3>Racing Sport</h3>
        {sportsData.slice(0, 2).map(sport => (
          <div 
            key={sport.id} 
            className={`sidebar-item ${selectedSport === sport.id ? 'active' : ''}`}
            onClick={() => setSelectedSport(sport.id)}
          >
            <span>{sport.name}</span>
            <span className="count">{sport.count}</span>
          </div>
        ))}
      </div>
      <div className="sidebar-section">
        <h3>All Sport</h3>
        {sportsData.slice(2).map(sport => (
          <div 
            key={sport.id} 
            className={`sidebar-item ${selectedSport === sport.id ? 'active' : ''}`}
            onClick={() => setSelectedSport(sport.id)}
          >
            <span>{sport.name}</span>
            <span className="count">{sport.count}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Sidebar

