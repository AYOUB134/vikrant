"use client"

import { useState } from "react"

const matchesData = [
  { id: 1, event: "Gujarat v Kerala", league: "Ranji Trophy Elite 2024-25", status: "Live" },
  { id: 2, event: "Vidarbha v Mumbai", league: "Ranji Trophy Elite 2024-25", status: "Live" },
  {
    id: 3,
    event: "Zimbabwe v Ireland",
    league: "One Day International",
    status: "Live",
    odds: { team1: 1.02, team2: 1.03 },
    scores: { team1: 38, team2: 40 },
  },
]

function MainContent() {
  const [activeTab, setActiveTab] = useState("Cricket")

  return (
    <div className="flex-1 p-4 overflow-y-auto">
      <div className="mb-4">
        <h2 className="text-2xl font-bold mb-2">Upcoming Fixtures</h2>
        {/* Add carousel/slider for upcoming fixtures here */}
      </div>

      <div className="mb-4">
        <div className="flex space-x-2 mb-2">
          {["Cricket", "Football", "Tennis", "Esoccer"].map((sport) => (
            <button
              key={sport}
              className={`px-4 py-2 rounded ${activeTab === sport ? "bg-blue-500 text-white" : "bg-gray-200"}`}
              onClick={() => setActiveTab(sport)}
            >
              {sport}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {matchesData.map((match) => (
            <div key={match.id} className="border p-4 rounded shadow">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-bold">{match.event}</h3>
                  <p className="text-sm text-gray-600">{match.league}</p>
                  {match.status === "Live" && <span className="text-red-500 text-sm">● Live</span>}
                </div>
                {match.odds ? (
                  <div className="flex space-x-2">
                    <button className="px-2 py-1 bg-blue-100 rounded">{match.odds.team1}</button>
                    <button className="px-2 py-1 bg-pink-100 rounded">{match.odds.team2}</button>
                    <button className="px-2 py-1 bg-blue-100 rounded">{match.scores.team1}</button>
                    <button className="px-2 py-1 bg-pink-100 rounded">{match.scores.team2}</button>
                  </div>
                ) : (
                  <span className="text-gray-500">🔒</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default MainContent

